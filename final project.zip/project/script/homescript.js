var myCarousel = document.querySelector('#carouselExampleAutoplaying');
var carousel = new bootstrap.Carousel(myCarousel, {
    interval: 3000,
    pause: false
});

